

export interface IPersonaje {
    _id : string;
    title : string;
    body : string;
    image : string;
    category : number;
    idAuthor : number;
    createdAt : Date;
    updatedAt : Date;
}